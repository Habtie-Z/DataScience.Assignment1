z = 4 
if z % 2 == 0 :
    print("z is even") 