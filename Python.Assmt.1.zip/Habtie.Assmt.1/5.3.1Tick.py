import matplotlib.pyplot as plt 
year = ... # Implementation left out 
population = ...  # Implementation left out 
plt.plot(year, population)
plt.show()
