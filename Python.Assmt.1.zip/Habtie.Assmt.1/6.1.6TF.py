z = 5 
if z % 2 == 0:
    print("z is even") 
    else:
        print("z is odd") 