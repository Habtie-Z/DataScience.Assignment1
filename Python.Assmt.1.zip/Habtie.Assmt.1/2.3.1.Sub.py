#Behind the scenes (1)

x = ["a", "b", "c"]
y = x

y[1] = "z"

print(y)
print(x)