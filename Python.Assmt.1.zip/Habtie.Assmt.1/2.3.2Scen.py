#round()

print(round(1.68, 1))
print(round(1.68))
