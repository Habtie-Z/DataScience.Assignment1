height = 1.79
weight = 68.7

bmi = weight/height ** 2

print(bmi)
print(type(bmi))