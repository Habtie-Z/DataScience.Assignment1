import pandas as pd
brics = pd.read_csv("C:/Users/Zewditu/Desktop/brics.csv", index_col = 0)
print(brics.loc[:,'Country'])