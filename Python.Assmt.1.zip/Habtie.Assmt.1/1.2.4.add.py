x= 2 + 3
y = 'ab' +'cd'       #Different type = different behavior!

print(x)
print(y)
