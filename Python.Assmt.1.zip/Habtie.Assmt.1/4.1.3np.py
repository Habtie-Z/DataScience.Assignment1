import numpy as np
x = np.array([1.0, "is", True])
print(x)
