import numpy as np
print(np.array([1, 2, 3]))