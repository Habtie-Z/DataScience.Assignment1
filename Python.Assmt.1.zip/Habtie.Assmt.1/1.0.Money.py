height = 1.79
weight = 74.2
bmi = weight / height ** 2
print(height)
print(bmi)
print(type(bmi))