z = 6 
if z % 2 == 0 :     
    print("z is divisible by 2") 
elif z % 3 == 0 :
    print("z is divisible by 3") 
else:
    print("z is neither divisible by 2 nor by 3") 