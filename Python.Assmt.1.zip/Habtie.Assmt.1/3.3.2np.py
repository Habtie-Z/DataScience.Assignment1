from numpy import array
print(array([1, 2, 3]))