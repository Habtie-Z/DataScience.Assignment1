z = 4 
if z % 2 == 0 :
    print("checking "  + str(z))     
    print("z is even") 