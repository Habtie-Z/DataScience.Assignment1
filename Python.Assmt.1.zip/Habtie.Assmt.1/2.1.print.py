height = [1.73, 1.68, 1.71, 1.89] 
fam = [1.73, 1.68, 1.71, 1.89] 

print(height)
print(fam)