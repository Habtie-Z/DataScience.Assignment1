import pandas as pd
brics = pd.read_csv("C:/Users/Zewditu/Desktop/brics.csv", index_col = 0)
brics["on_earth"] = brics.apply(lambda column: True, axis = 1) 
print(brics)