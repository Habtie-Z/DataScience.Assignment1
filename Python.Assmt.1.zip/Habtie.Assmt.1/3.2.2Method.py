fam = ["liz", 1.73, "emma", 1.68, "mom", 1.71, "dad", 1.89]      #list methods
print(fam)
fam.append("me")

print(fam)

fam.append(1.79)

print(fam)

print(type(fam))

print(fam.index("dad"))