day_of_week = 5
x = "body mass index"
y = 'this works too'
z= True

print(type(day_of_week))
print(type(y))
print(type(z))