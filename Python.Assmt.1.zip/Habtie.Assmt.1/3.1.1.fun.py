fam = [1.73, 1.68, 1.71, 1.89]
print(fam)
print(max(fam))
tallest = max(fam) 
print(tallest)