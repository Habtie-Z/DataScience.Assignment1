print(True or True) 
print(True or False)
print(False or True)
print(False or False)  
y = 5 
print(y <= 7 or y > 13)
print(not True)
print(not False) 