sister = "liz"
height = 1.73
fam = ["liz", 1.73, "emma", 1.68, "mom", 1.71, "dad", 1.89]      #list methods

print(fam)
print(fam.index("mom"))
print(fam.count(1.73))
print(sister)          #str methods
print(sister.capitalize())
print(sister.replace("z", "sa"))