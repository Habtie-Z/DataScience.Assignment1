print(2 < 3)
print(2 == 3) 
x = 2 
y = 3 
print(x < y)
print( x == y ) 
print( True and True )
print(False and True)
print(True and False)
print(False and False )
z = 12 
print(z > 5 and z < 15) 