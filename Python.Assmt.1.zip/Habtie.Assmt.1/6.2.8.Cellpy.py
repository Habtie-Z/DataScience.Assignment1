import pandas as pd
brics = pd.read_csv("C:/Users/Zewditu/Desktop/brics.csv", index_col = 1)
brics = brics.set_index("Abbr.", drop = False)
print(brics.loc["CH"]["Capital"])